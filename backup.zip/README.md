# STM32 base project

## `make` commands

Run `make` to compile the code.

```sh { closeTerminalOnSuccess=false }
# compile code
make
```

Run `make clean` to remove the compiled code. This does not remove the backup.

```sh { closeTerminalOnSuccess=false }
# clean up
make clean
```

Run `make flash` to flash the code to the board.

```sh { closeTerminalOnSuccess=false }
# flash to board
make flash
```

Run `make erase` to erase the code from the board.

```sh { closeTerminalOnSuccess=false }
# erase from board
make erase
```

## `make` variables

Run `make` with `DEBUG=0` to compile the code without debug information.

```sh { closeTerminalOnSuccess=false }
# compile code without debug information
make DEBUG=0
```

Make sure to also flash with `DEBUG=0` as both versions are kept in the build folder.
    
```sh { closeTerminalOnSuccess=false }
# flash to board without debug information
make flash DEBUG=0
```

## `make` arguments

Run `make` with `V=1` to see the commands that are executed.

```sh { closeTerminalOnSuccess=false }
# show commands
make V=1
```